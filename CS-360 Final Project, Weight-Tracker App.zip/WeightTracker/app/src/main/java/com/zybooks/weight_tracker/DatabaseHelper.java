package com.zybooks.weight_tracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Centralized database helper responsible for all persistent storage.
 * <p>
 * This class intentionally keeps all SQL logic in one place to:
 * - avoid duplication across activities
 * - simplify schema changes
 * - make user and weight relationships explicit
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // =====================================================
    // Database configuration
    // =====================================================

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    // =====================================================
    // USERS TABLE
    // =====================================================

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Goal-related columns are stored with the user so goals
    // persist independently of individual weight entries.
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    public static final String COLUMN_GOAL_START_WEIGHT = "goal_start_weight";

    // =====================================================
    // WEIGHTS TABLE
    // =====================================================

    public static final String TABLE_WEIGHTS = "weights";
    public static final String COLUMN_WEIGHT_ID = "id";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_USER_FK = "user_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // =====================================================
    // Database lifecycle
    // =====================================================

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Users table stores authentication and goal data.
        // Goal weights are stored with the user rather than a separate table
        // since each user has only one active goal at a time.

        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USERNAME + " TEXT UNIQUE, " +
                        COLUMN_PASSWORD + " TEXT, " +
                        COLUMN_GOAL_WEIGHT + " REAL, " +
                        COLUMN_GOAL_START_WEIGHT + " REAL)";

        // Weights table stores historical entries per user.
        // Foreign key ensures entries cannot exist without a user.
        String createWeightsTable =
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_DATE + " TEXT, " +
                        COLUMN_WEIGHT + " REAL, " +
                        COLUMN_USER_FK + " INTEGER, " +
                        "FOREIGN KEY(" + COLUMN_USER_FK + ") REFERENCES " +
                        TABLE_USERS + "(" + COLUMN_USER_ID + "))";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For this project, schema changes are handled by rebuilding.
        // This avoids migration complexity and keeps logic clear.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // =====================================================
    // User / authentication methods
    // =====================================================

    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        return db.insert(TABLE_USERS, null, values) != -1;
    }

    public boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + "=? AND " +
                        COLUMN_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_USER_ID +
                        " FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + "=?",
                new String[]{username}
        );

        int id = -1;
        if (cursor.moveToFirst()) {
            id = cursor.getInt(0);
        }

        cursor.close();
        return id;
    }

    // =====================================================
    // Goal-related methods
    // =====================================================

    /**
     * Updates the user's goal weight and captures the weight at the time the goal was set.
     * Storing the starting weight allows goal direction (gain vs. loss) to be determined
     * reliably even if the user later edits their goal.
     */
    public boolean updateGoalWeight(int userId, double goalWeight, double startWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);
        values.put(COLUMN_GOAL_START_WEIGHT, startWeight);

        return db.update(
                TABLE_USERS,
                values,
                COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)}
        ) > 0;
    }

    public double getGoalWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_GOAL_WEIGHT +
                        " FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)}
        );

        double goal = -1;
        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(0);
        }

        cursor.close();
        return goal;
    }

    // =====================================================
    // Weight entry CRUD methods
    // =====================================================

    public boolean insertWeight(String date, double weight, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_USER_FK, userId);

        return db.insert(TABLE_WEIGHTS, null, values) != -1;
    }

    public Cursor getAllWeights(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_WEIGHTS +
                        " WHERE " + COLUMN_USER_FK + "=? " +
                        " ORDER BY " + COLUMN_WEIGHT_ID + " DESC",
                new String[]{String.valueOf(userId)}
        );
    }

    /**
     * Retrieves the weight entry immediately before the most recent one.
     * This is used to determine whether the user crossed their goal
     * threshold between two consecutive entries.
     */
    public Double getPreviousWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_WEIGHT +
                        " FROM " + TABLE_WEIGHTS +
                        " WHERE " + COLUMN_USER_FK + "=? " +
                        " ORDER BY " + COLUMN_WEIGHT_ID +
                        " DESC LIMIT 1 OFFSET 1",
                new String[]{String.valueOf(userId)}
        );

        Double previous = null;
        if (cursor.moveToFirst()) {
            previous = cursor.getDouble(0);
        }

        cursor.close();
        return previous;
    }

    public Double getLatestWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_WEIGHT +
                        " FROM " + TABLE_WEIGHTS +
                        " WHERE " + COLUMN_USER_FK + "=? " +
                        " ORDER BY " + COLUMN_WEIGHT_ID +
                        " DESC LIMIT 1",
                new String[]{String.valueOf(userId)}
        );

        Double latest = null;
        if (cursor.moveToFirst()) {
            latest = cursor.getDouble(0);
        }

        cursor.close();
        return latest;
    }

    public boolean updateWeight(int id, String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        return db.update(
                TABLE_WEIGHTS,
                values,
                COLUMN_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(
                TABLE_WEIGHTS,
                COLUMN_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }
}