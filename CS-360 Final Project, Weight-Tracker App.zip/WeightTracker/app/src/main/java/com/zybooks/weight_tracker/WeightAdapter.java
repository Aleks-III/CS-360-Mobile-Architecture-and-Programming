package com.zybooks.weight_tracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter responsible for binding weight history data to the RecyclerView.
 * <p>
 * This adapter delegates edit and delete actions back to the hosting activity
 * to keep UI rendering separate from navigation and database logic.
 */
class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    /**
     * Callback for edit actions initiated from a list item.
     */
    public interface OnEditClickListener {
        void onEdit(WeightEntry entry);
    }

    /**
     * Callback for delete actions initiated from a list item.
     */
    public interface OnDeleteClickListener {
        void onDelete(WeightEntry entry);
    }

    private final List<WeightEntry> weightList;
    private final OnEditClickListener editListener;
    private final OnDeleteClickListener deleteListener;

    public WeightAdapter(
            List<WeightEntry> weightList,
            OnEditClickListener editListener,
            OnDeleteClickListener deleteListener
    ) {
        this.weightList = weightList;
        this.editListener = editListener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {

        WeightEntry entry = weightList.get(position);

        holder.dateText.setText(entry.getDate());

        // Uses a string resource for localization and consistent formatting
        holder.weightText.setText(
                holder.itemView.getContext().getString(
                        R.string.weight_display,
                        entry.getWeight()
                )
        );

        holder.editButton.setOnClickListener(
                v -> editListener.onEdit(entry)
        );

        holder.deleteButton.setOnClickListener(
                v -> deleteListener.onDelete(entry)
        );
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    /**
     * ViewHolder that caches references to item views for performance.
     * <p>
     * Declared static to avoid holding implicit references to the adapter or activity context.
     */
    public static class WeightViewHolder extends RecyclerView.ViewHolder {

        final TextView dateText;
        final TextView weightText;
        final ImageButton editButton;
        final ImageButton deleteButton;

        WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
            weightText = itemView.findViewById(R.id.weightText);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}