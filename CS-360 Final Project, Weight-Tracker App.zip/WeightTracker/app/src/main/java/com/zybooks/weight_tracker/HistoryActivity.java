package com.zybooks.weight_tracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

/**
 * Displays the user's weight history and provides entry management (add, edit, delete).
 * <p>
 * This screen acts as the primary navigation hub after login.
 */
public class HistoryActivity extends AppCompatActivity {

    // =====================================================
    // Fields
    // =====================================================

    private DatabaseHelper databaseHelper;
    private int userId;

    private RecyclerView recyclerView;

    // =====================================================
    // Activity lifecycle
    // =====================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        databaseHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);

        recyclerView = findViewById(R.id.historyRecycler);

        MaterialButton newEntryButton = findViewById(R.id.newEntryButton);
        MaterialButton logoutButton = findViewById(R.id.logoutButton);

        newEntryButton.setOnClickListener(v -> launchNewEntry());
        logoutButton.setOnClickListener(v -> logout());

        loadWeightHistory();
    }

    // =====================================================
    // Data loading
    // =====================================================

    /**
     * Loads all stored weight entries for the current user and binds them to the RecyclerView.
     * <p>
     * The adapter is recreated to ensure the UI stays in sync after edits or deletions.
     */
    private void loadWeightHistory() {
        List<WeightEntry> weightList = new ArrayList<>();
        Cursor cursor = databaseHelper.getAllWeights(userId);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT_ID)
                );
                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE)
                );
                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT)
                );

                weightList.add(new WeightEntry(id, date, weight));
            }
            cursor.close();
        }

        WeightAdapter adapter = new WeightAdapter(
                weightList,
                this::editEntry,
                this::deleteEntry
        );

        recyclerView.setAdapter(adapter);
    }

    // =====================================================
    // Entry actions
    // =====================================================

    /**
     * Launches the daily entry screen for creating a new weight entry.
     */
    private void launchNewEntry() {
        Intent intent = new Intent(this, DailyWeightActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    /**
     * Launches the daily entry screen with an existing entry preloaded for editing.
     */
    private void editEntry(WeightEntry entry) {
        Intent intent = new Intent(this, DailyWeightActivity.class);
        intent.putExtra("USER_ID", userId);
        intent.putExtra("ENTRY_ID", entry.getId());
        intent.putExtra("ENTRY_WEIGHT", entry.getWeight());
        startActivity(intent);
    }

    /**
     * Removes an entry from the database and refreshes the list to reflect the change immediately.
     */
    private void deleteEntry(WeightEntry entry) {
        boolean deleted = databaseHelper.deleteWeight(entry.getId());

        if (!deleted) {
            Toast.makeText(this, "Failed to delete entry", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
        loadWeightHistory();
    }

    // =====================================================
    // Session management
    // =====================================================

    /**
     * Clears the login state and returns the user to the login screen,
     * removing this activity from the back stack.
     */
    private void logout() {
        getSharedPreferences("UserPrefs", MODE_PRIVATE)
                .edit()
                .clear()
                .apply();

        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}