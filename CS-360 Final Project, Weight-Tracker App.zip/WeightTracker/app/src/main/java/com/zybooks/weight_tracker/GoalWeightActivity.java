package com.zybooks.weight_tracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Allows the user to define or update a single active goal weight.
 * <p>
 * This screen also controls whether SMS notifications are enabled,
 * but permission is only requested if the user explicitly opts in.
 */
public class GoalWeightActivity extends AppCompatActivity {

    // =====================================================
    // Fields
    // =====================================================

    private DatabaseHelper databaseHelper;
    private int userId;

    private TextInputEditText goalWeightField;

    // =====================================================
    // Activity lifecycle
    // =====================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        databaseHelper = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("USER_ID", -1);

        goalWeightField = findViewById(R.id.goalWeightField);

        MaterialButton saveButton = findViewById(R.id.saveGoalButton);
        MaterialButton logoutButton = findViewById(R.id.logoutButton);
        SwitchMaterial smsToggle = findViewById(R.id.smsToggle);

        saveButton.setOnClickListener(v -> saveGoalWeight());

        // Initialize toggle from per-user preferences so
        // SMS settings do not carry over between users
        SharedPreferences prefs = getUserSmsPrefs();
        smsToggle.setChecked(
                prefs.getBoolean(SMSPermissionActivity.SMS_ENABLED, false)
        );

        smsToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Permission is requested only when the user
                // explicitly enables notifications
                Intent intent = new Intent(this, SMSPermissionActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
            } else {
                prefs.edit()
                        .putBoolean(SMSPermissionActivity.SMS_ENABLED, false)
                        .apply();
            }
        });

        logoutButton.setOnClickListener(v -> logout());
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Sync toggle state after returning from the
        // permission screen
        SwitchMaterial smsToggle = findViewById(R.id.smsToggle);
        smsToggle.setChecked(
                getUserSmsPrefs().getBoolean(SMSPermissionActivity.SMS_ENABLED, false)
        );
    }

    // =====================================================
    // Persistence helpers
    // =====================================================

    /**
     * SMS preferences are stored per-user to prevent
     * notification settings from leaking across accounts.
     */
    private SharedPreferences getUserSmsPrefs() {
        return getSharedPreferences(
                SMSPermissionActivity.PREFS_NAME + "_user_" + userId,
                MODE_PRIVATE
        );
    }

    // =====================================================
    // Goal handling
    // =====================================================

    /**
     * Saves the goal weight and captures the user's
     * current weight as the baseline for goal evaluation.
     * <p>
     * Using the latest recorded weight avoids incorrect
     * notifications if the goal is later edited.
     */
    private void saveGoalWeight() {

        Editable editable = goalWeightField.getText();
        String input = editable != null ? editable.toString().trim() : "";

        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double goalWeight;
        try {
            goalWeight = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight value", Toast.LENGTH_SHORT).show();
            return;
        }

        Double latestWeight = databaseHelper.getLatestWeight(userId);

        // If no history exists yet, treat the goal itself
        // as the starting point to avoid false crossings
        double startWeight = (latestWeight != null)
                ? latestWeight
                : goalWeight;

        boolean saved =
                databaseHelper.updateGoalWeight(userId, goalWeight, startWeight);

        if (!saved) {
            Toast.makeText(this, "Failed to save goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, DailyWeightActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        finish();
    }

    // =====================================================
    // Session management
    // =====================================================

    private void logout() {

        // Clearing login state ensures the next app launch requires authentication
        getSharedPreferences("UserPrefs", MODE_PRIVATE)
                .edit()
                .clear()
                .apply();

        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}