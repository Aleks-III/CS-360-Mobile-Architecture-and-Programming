package com.zybooks.weight_tracker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Handles daily weight entry and goal evaluation.
 * <p>
 * This activity supports both:
 * - creating a new weight entry
 * - editing an existing entry (when ENTRY_ID is provided)
 */
public class DailyWeightActivity extends AppCompatActivity {

    // =====================================================
    // Fields
    // =====================================================

    private DatabaseHelper databaseHelper;
    private int userId;
    private int entryId = -1;

    private TextInputEditText weightField;

    // =====================================================
    // Activity lifecycle
    // =====================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_weight);

        databaseHelper = new DatabaseHelper(this);

        userId = getIntent().getIntExtra("USER_ID", -1);
        entryId = getIntent().getIntExtra("ENTRY_ID", -1);

        weightField = findViewById(R.id.weightField);

        MaterialButton saveButton = findViewById(R.id.submitWeightButton);
        MaterialButton editGoalButton = findViewById(R.id.editGoalButton);
        MaterialButton logoutButton = findViewById(R.id.logoutButton);

        // Pre-fill the field when editing an existing entry
        if (entryId != -1) {
            double existingWeight = getIntent().getDoubleExtra("ENTRY_WEIGHT", 0);
            weightField.setText(String.valueOf(existingWeight));
        }

        saveButton.setOnClickListener(v -> saveWeight());

        editGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, GoalWeightActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        logoutButton.setOnClickListener(v -> logout());
    }

    // =====================================================
    // Persistence helpers
    // =====================================================

    /**
     * SMS preferences are stored per-user to prevent notification
     * settings from carrying over when multiple users log in.
     */
    private SharedPreferences getUserSmsPrefs() {
        return getSharedPreferences(
                SMSPermissionActivity.PREFS_NAME + "_user_" + userId,
                MODE_PRIVATE
        );
    }

    // =====================================================
    // Weight saving logic
    // =====================================================

    private void saveWeight() {
        Editable editable = weightField.getText();
        String weightInput = editable != null ? editable.toString().trim() : "";

        if (weightInput.isEmpty()) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight;
        try {
            weight = Double.parseDouble(weightInput);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight value", Toast.LENGTH_SHORT).show();
            return;
        }

        String date = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
                .format(new Date());

        boolean success;

        if (entryId == -1) {
            success = databaseHelper.insertWeight(date, weight, userId);
        } else {
            success = databaseHelper.updateWeight(entryId, date, weight);
        }

        if (!success) {
            Toast.makeText(this, "Failed to save weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // Only check goals after a successful save so
        // goal logic reflects persisted data
        checkAndSendSms(weight);

        Intent intent = new Intent(this, HistoryActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        finish();
    }

    // =====================================================
    // Goal evaluation logic
    // =====================================================

    /**
     * Determines whether the user's goal was crossed between
     * the previous entry and the current one.
     * <p>
     * This avoids false positives when users edit past entries
     * or repeatedly log weights beyond the goal threshold.
     */
    private boolean isGoalReached(double currentWeight) {

        double goalWeight = databaseHelper.getGoalWeight(userId);
        if (goalWeight <= 0) return false;

        Double previousWeight = databaseHelper.getPreviousWeight(userId);

        // Without a previous value, a crossing cannot be detected
        if (previousWeight == null) return false;

        // Losing weight: crossed from above → below
        if (previousWeight > goalWeight && currentWeight <= goalWeight) {
            return true;
        }

        // Gaining weight: crossed from below → above
        return previousWeight < goalWeight && currentWeight >= goalWeight;
    }

    private void checkAndSendSms(double weight) {
        SharedPreferences prefs = getUserSmsPrefs();

        boolean smsEnabled =
                prefs.getBoolean(SMSPermissionActivity.SMS_ENABLED, false);

        if (!smsEnabled) return;

        if (isGoalReached(weight)) {

            // Emulator-visible confirmation since SMS delivery
            // is unreliable in development environments
            Toast.makeText(this,
                    "Goal reached!",
                    Toast.LENGTH_LONG).show();

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    "+15551234567",
                    null,
                    "Weight Alert: You have reached your goal weight!",
                    null,
                    null
            );
        }
    }

    // =====================================================
    // Session management
    // =====================================================

    private void logout() {
        // Clear stored login state so the next launch
        // requires authentication
        getSharedPreferences("UserPrefs", MODE_PRIVATE)
                .edit()
                .clear()
                .apply();

        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}